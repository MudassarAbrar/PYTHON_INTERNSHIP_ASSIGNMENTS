'''

Write a function named Capital_Convertor() that get the name from user and return the
name is in Capital/Block Letters.
'''

def Capital_Convertor(name):
    return name.upper()



user_name = input("ENTER YOUR NAME HERE :  ")
print(Capital_Convertor(user_name))