'''

9. Why do we use functions in Python? Explain at least three advantages of using functions
in programming with examples. (Not required coding, theory question)

'''



#1st advantage: Functions increase the reusibilty of the program.
#2nd advantage: Functions increase the scablibility of the program.
#3rd advantage: Functions make the code consise , clear and easy to manage.
#4th advantage: Functions make the code modular.